package com.alipay.sofa.jraft.storage;

public interface Storage {
}
