package com.alipay.sofa.jraft.option;


public enum ApplyTaskMode {
    Blocking, NonBlocking
}