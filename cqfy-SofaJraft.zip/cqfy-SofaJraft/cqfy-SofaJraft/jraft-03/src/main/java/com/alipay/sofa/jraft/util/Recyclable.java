package com.alipay.sofa.jraft.util;


public interface Recyclable {

    /**
     * Recycle this instance.
     */
    boolean recycle();
}